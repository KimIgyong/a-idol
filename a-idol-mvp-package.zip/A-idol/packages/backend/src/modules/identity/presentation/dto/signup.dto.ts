import { ApiProperty } from '@nestjs/swagger';
import { IsDateString, IsEmail, IsOptional, IsString, MaxLength, MinLength } from 'class-validator';

export class SignupDto {
  @ApiProperty({ example: 'demo@a-idol.dev' })
  @IsEmail()
  email!: string;

  @ApiProperty({ example: 'password123', minLength: 8, maxLength: 64 })
  @IsString()
  @MinLength(8)
  @MaxLength(64)
  password!: string;

  @ApiProperty({ example: 'demo', maxLength: 30 })
  @IsString()
  @MaxLength(30)
  nickname!: string;

  @ApiProperty({ example: '2000-01-01' })
  @IsDateString()
  birthdate!: string;

  @ApiProperty({ required: false, example: 'iphone-XYZ' })
  @IsOptional()
  @IsString()
  deviceId?: string;
}
